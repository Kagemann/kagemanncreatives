<?php
/**
 * Title: Contact Section
 * Slug: kagemann/contact
 * Categories: kagemann
 */
?>
<!-- wp:group {"className":"section-pad"} -->
<div class="wp-block-group section-pad">
  <div class="container">
    <!-- wp:heading {"level":2} --><h2>Contact</h2><!-- /wp:heading -->
    <!-- wp:paragraph --><p>Email <a href="mailto:hello@kagemanncreatives.com">hello@kagemanncreatives.com</a> or use the form below.</p><!-- /wp:paragraph -->
    <!-- wp:shortcode -->[contact-form]<!-- /wp:shortcode -->
  </div>
</div>
<!-- /wp:group -->

